Los mejores indicadores para Mt4 y Mt5   en : https://t.me/indicatorsmt5mt4
los mejores libros de trading: https://t.me/tradingpdfgratis2

The best indicators for Mt5 and Mt4 in : https://t.me/indicatorsmt5mt4
The best books about trading in https://t.me/tradingpdfgratis2

gracias por seguirnos 
Thanks for follow us 